==========
tradedefender
==========

A tool for accessing and analyzing financial data provided by Trade Defender.

Requires: requests

Installation: pip install tradedefender

For usage examples see: https://tradedefender.com/docs
